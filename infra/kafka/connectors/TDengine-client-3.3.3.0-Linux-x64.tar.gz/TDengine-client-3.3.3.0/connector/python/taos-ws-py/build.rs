fn main() {
    shadow_rs::new().unwrap();
}
