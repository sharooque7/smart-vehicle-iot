python3 -m maturin build --strip && pip3 install ./target/wheels/taos_ws_py-0.2.4-cp37-abi3-manylinux_2_31_x86_64.whl --force-reinstall
